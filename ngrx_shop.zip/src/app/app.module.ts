import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { StoreModule } from '@ngrx/store'; 
import { AppComponent } from './app.component';
import { appReducer } from './store/reducers/app.reducer';
import { ShoppingComponent } from './shopping/shopping.component';
import { HttpClientModule } from '@angular/common/http';
import { EffectsModule } from '@ngrx/effects';
import { ShoppingEffects } from './store/effects/shopping.effects';


@NgModule({
  declarations: [
    AppComponent,
    ShoppingComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    StoreModule.forRoot(appReducer),
    HttpClientModule,
    EffectsModule.forRoot([ShoppingEffects])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
