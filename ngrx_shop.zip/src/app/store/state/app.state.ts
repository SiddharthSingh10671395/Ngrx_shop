import { ICartState, initialCartState, initialUserState, IUserState } from "./cart-state";

export interface IAppState{
    items:ICartState;
   
    users: IUserState;
}

export const initialAppState:IAppState={
    users: initialUserState,
    items:initialCartState
}

export function getInitialState():IAppState{
    return initialAppState;
}