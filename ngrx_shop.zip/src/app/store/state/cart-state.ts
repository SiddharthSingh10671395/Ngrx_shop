import { IShoppingItem, IUser } from "src/app/store/models/shopping-item.model";

export interface ICartState{
    items:IShoppingItem[],
    loading: boolean,
  error: Error
    
}
export interface IUserState {
    users: IUser[];
    selectedUser: IUser;
  }

export const initialCartState:ICartState={
    items:[
        {id:"12121",name:"Diet Coke"}
    ],
    loading: false,
    error: undefined
}


export const initialUserState: IUserState = {
  users: null,
  selectedUser: null
};
