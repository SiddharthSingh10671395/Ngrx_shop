export interface IShoppingItem {
   
    name: string;
    id: string;
 }

 export interface IUser {
    id: number;
    name: string;
    cardNumber: string;
    cardType: string;
  }
  