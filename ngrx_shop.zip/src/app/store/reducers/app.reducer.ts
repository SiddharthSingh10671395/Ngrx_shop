import { ActionReducerMap } from "@ngrx/store";
import { IAppState } from "../state/app.state";
import { cartReducers } from "./shopping.reducers";
import { userReducers } from "./user.reducers";

//we need for each element of appReducer to have ..a pairing with an element of 
//Iappstate...i.e - for each appstate one reducer
export const appReducer:ActionReducerMap<IAppState,any>={
    users: userReducers,
    items:cartReducers,

}