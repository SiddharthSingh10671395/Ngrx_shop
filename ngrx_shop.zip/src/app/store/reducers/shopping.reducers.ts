
import { ShoppingActionTypes, ShoppingAction } from '../actions/shopping.actions';
import { IShoppingItem } from '../models/shopping-item.model';
import { ICartState, initialCartState } from '../state/cart-state';


export const cartReducers=(state=initialCartState
    ,action:ShoppingAction):ICartState=>{
            switch(action.type){
                case ShoppingActionTypes.LOAD_SHOPPING:
                    return {
                      ...state,
                      loading: true
                    }
                  case ShoppingActionTypes.LOAD_SHOPPING_SUCCESS:
                    return {
                      ...state,
                      items: action.payload,
                      loading: false
                    }
                  
                  case ShoppingActionTypes.LOAD_SHOPPING_FAILURE: 
                    return {
                      ...state,
                      error: action.payload,
                      loading: false
                    }
                  
                  case ShoppingActionTypes.ADD_ITEM:
                    return {
                      ...state,
                      loading: true
                    }
                  case ShoppingActionTypes.ADD_ITEM_SUCCESS:
                    return {
                      ...state,
                      items: [...state.items, action.payload],
                      loading: false
                    };
                  case ShoppingActionTypes.ADD_ITEM_FAILURE:
                    return {
                      ...state,
                      error: action.payload,
                      loading: false
                    };
                  case ShoppingActionTypes.DELETE_ITEM:
                    return {
                      ...state,
                      loading: true
                    };
                  case ShoppingActionTypes.DELETE_ITEM_SUCCESS:
                    return {
                      ...state,
                      items: state.items.filter(item => item.id !== action.payload),
                      loading: false
                    }
                  case ShoppingActionTypes.DELETE_ITEM_FAILURE:
                    return {
                      ...state,
                      error: action.payload,
                      loading: false
                    };
                  default:
                    return state;
                }
            }
    
