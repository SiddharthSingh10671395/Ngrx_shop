import { createSelector } from "@ngrx/store";
import { IAppState } from "../state/app.state";
import { ICartState } from "../state/cart-state";



const selectItems=(state:IAppState)=>state.items;



export const selectItemList=createSelector(
    selectItems,
    (state:ICartState)=>state.items

);

export const selectLoading=createSelector(
    selectItems,
    (state:ICartState)=>state.loading

);

export const selectError=createSelector(
    selectItems,
    (state:ICartState)=>state.error

);