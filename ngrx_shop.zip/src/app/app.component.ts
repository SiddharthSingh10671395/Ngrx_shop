import { Component } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { AddItemAction, DeleteItemAction } from './store/actions/shopping.actions';
import { IShoppingItem } from './store/models/shopping-item.model';
import { cartReducers } from './store/reducers/shopping.reducers';
import { selectItemList ,selectLoading,selectError} from './store/selectors/item.selector';
import { IAppState } from './store/state/app.state';
import { ICartState } from './store/state/cart-state';
import { v4 as uuid } from 'uuid';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'shop';
 
  shoppingItems$=this._store.pipe(select(selectItemList));
  loading$: Observable<Boolean>;
  error$: Observable<Error>
  
  newShoppingItem: IShoppingItem = { id: '', name: '' }
  constructor(private _store: Store<IAppState>) {}
  ngOnInit() {
    this.loading$=this._store.pipe(select(selectLoading))
    this.error$=this._store.pipe(select(selectError));
    
  }
  addItem(){
    this.newShoppingItem.id = uuid();
   //newItem.id="12";
  // newItem.name=this.newShoppingItem;
  this._store.dispatch(new AddItemAction(this.newShoppingItem));

  this.newShoppingItem = { id: '', name: '' };

  }
  deleteItem(id: string) {
    this._store.dispatch(new DeleteItemAction(id));
  }
 
}
